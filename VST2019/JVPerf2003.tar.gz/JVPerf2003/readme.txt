Dear User,

You have downloaded the complete JVPerf2003 zipfile version 2.0.1.4
Please test and check this program very well in the 45 day trial period if it will fit your needs.
Once you decide to buy a key, no refunds will be made.

This is what you need to know before unzipping:

Unzip to a directory of your choice. When you use [Use Directory Names]
in winzip 7.x it will create a directory JVPerf2003.

When unzipped here's a Quick Start:

Double click on the JVPerf2003 icon. The program will start.
When you right-click you can make a shortcut. Dragdrop it to 
a place you think is usefull. 

The first time you have to select the mididevices: [settings]-[midi & exp boards].
Only select the option [separate keyboard] if you have more than
one midi-input and want to audition using a masterkeyboard. 
Also select your Expansionboards here and your JV-XP type (jv1010, 1080, 2080, xp-30, 50, 60, 80) if you have set a different ID for the JV or XP type it in the ID field (default is 17).
Don't forget to select the right JV or XP type!

Exit the program and start again so the changes on expansions 
and unit-type can take effect.

In JVPerform99 click the [Get Temp] button. Or drag drop a sysexfile with performances in it on the mainscreen. Or click [Open Sysex]. 
The performance will load in the program. 
Edit or tweaken the performance as you wish, give it a name and save it
to a usermemory place in your JV-XP, or to disk [File]-[Save Syx].

Watch it. JVPerform will only write performance data to this syx-file!
When you dropped or opened a file with patches and/or rhythm data in it, and you give it the same name, the original data (patch / rhythm) will be lost.
Save to a new file with a different (new) name instead.

With all the expansion and preset patches you might find the Patch-Finder quite usefull. Click the little folder in the patchselect window. It's great to compare patches. Type 3 characters at minimum, 
8 at maximum.

-Use 	[Ctrl] or [Shift] to go in 10 or 5 steps when using the spineditbox
	with the 'rolling'-mouse. This can work a lot faster.

-Use your computerkeyboard:
	[Home]   = 0 or minimal value.
	[Insert] = middle of value. 
	[End]    = maximal value.
	[PgUp]  =  +10,
	[PgDn]  =  -10],

num	[+] or [Arrow-Up] = +1,
num	[-] or [Arrow-Dn] = -1.

-You can choose the height and velocity of the editnote 
 with the noteoutform, see menu options or press [F10].

-Set PlayNote on/off while editing with the little speaker 
 above-right in the part edit window.

know bugs and issues:
the [send all] bottun does not function. you can send one performance at a time
which you saved on disk or send a performance to the JV.

Have fun,
A helpfile will follow. Check the www.page.

Nils Andriessen, january 2003. 

email: <dreamstd@ision.nl>
  www:  http://www.nilsandriessen.com

This program is brought to you by Dream Studio-SWare.



Disclaimer of warranty:
DS-SWare exclude any and all implied warranties, including warranties of merchantability and fitness for a particular purpose. DS-SWare will not have any liability for special, incidental, or consequential damages arising out of or resulting from any use of this product.

